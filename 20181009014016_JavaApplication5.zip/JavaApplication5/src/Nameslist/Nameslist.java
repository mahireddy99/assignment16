package nameslist;

import java.util.Scanner;

public class Nameslist {
	
	 String[] names;


		      public static void main(String[] args) {
		    	
		        
		        	String[] names1=new String[10];
					
		
				
				 names1[0]="Jonathan";
				 names1[1]="Roxanne";
				 names1[2]="Jasmine";
				 names1[3]="Sophianne";
				 names1[4]="";
				 names1[5]="";
				 names1[6]="";
				 names1[7]="";
				 names1[8]="";
				 names1[9]="";
				 mainmenu(names1);
		        }
				
		     public static void mainmenu(String[] vector)  { 
				
				while(true)
				{
					
					System.out.println("MAIN MENU:");
					System.out.println("1. Display The List");
					System.out.println("2. Insert An Element");
					System.out.println("3. Swap Two Element");
					System.out.println("4. Quit");
					System.out.println("\nYour Choice?");
					Scanner sc=new Scanner (System.in);
					int keyboard=sc.nextInt();
					
					int n =sc.nextInt();

					

					if(n==1) {

						print(vector);

						System.out.println("LIST CONTENT:");

						listcontent(vector);

						mainmenu(vector);

					}

					else if(n==2) {

						insertName(vector);

						mainmenu(vector);

					}

					else if(n==3) {

						swaptwoelements(vector);

						mainmenu(vector);

					}

					

				

					else if (n==4) {

						System.out.println("");

					}

					else {

						System.out.println(" Choose the exact option");

						mainmenu(vector);

					}

						

					

				}
					
				}

private static void insertName(String[] vector) {
				// TODO Auto-generated method stub
				
			}

private static void listcontent(String[] vector) {
				// TODO Auto-generated method stub
				
			}

private static void print(String[] vector) {
				// TODO Auto-generated method stub
				
			}

public static void display(String[] vector) {

	for(int i=0;i<=9;i++){

		System.out.println(i+1 +". " +vector[i] );	

		

		}

	
				
		        }
		     
		     public static void insertName(int position, String name)
		     
				{
		    	 Scanner sc=new Scanner(System.in);
		    	 			
					if(position==0 || position>=10)
					{
						System.out.println("Please Enter Valid Position");
						
						position = sc.nextInt();
						insertName(position, name);
					}
					else if(name.equals(" ") || name.equals(null))
					{
						System.out.println("Please Enter Valid Name");
						
						name = sc.next();
						insertName(position, name);
					}
					else
					{
						String[] names;
						if(!names[position].equals(""))
						{
							System.out.println("There is already a name at this position, Please enter another positon to insert the name");
							Scanner keyboard;
							position = keyboard.nextInt();
							insertName(position, name);
							
						}
						else
						{
							names[position-1]=name;
							System.out.println("Value Insert Successfully");
							
						}
					}	
					
				}

		     
		     public static void swaptwoelements(String[] vector) {
		     
		        
		         System.out.println("from element");
		      
		         Scanner sc1=new Scanner(System.in);
		         int sc=sc1.nextInt();
		         System.out.println("from element");
		      
		         int swap=sc1.nextInt();
		         String names1 = null;

		 		int n;
				names1=vector[n-1];

		 		int s;
				vector[n-1]=vector[s-1];

		 		vector[s-1]=names1;

		 		System.out.print("SWAP TWO ELEMENTS");
		 		
		        
		     }




}



}
}

		